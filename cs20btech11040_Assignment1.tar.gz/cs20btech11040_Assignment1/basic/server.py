import socket

#WRITE CODE HERE:
#1. Create a KEY-VALUE pairs (Create a dictionary OR Maintain a text file for KEY-VALUES).


dst_ip = "10.0.1.2"
# str(input("Enter Server IP: "))

s = socket.socket()
print ("Socket successfully created")

dport = 12346

s.bind((dst_ip, dport))
print ("socket binded to %s" %(dport))

s.listen(5)
print ("socket is listening")

data = {}

while True:
  c, addr = s.accept()
  print ('Got connection from', addr )
  recvmsg = c.recv(1024).decode()
  print('Server received '+recvmsg)
  c.send('Hello client'.encode())
  while True:
      print("\n")
      recvmsg = c.recv(1024).decode()
      if len(recvmsg)==0:
          break
      print('Server received '+recvmsg)
      # if recvmsg[0:3] == "end":
      #     c.send("your session ended".encode())
      #     break
      if recvmsg[0:3] == "GET":
          key = recvmsg.split("?")[1].split("=")[1].split()[0]
          try:
             msg = "HTTP /1.1 200 OK"+"\nvalue: " + data[key]+'\r\n\r\n'
             c.send(msg.encode())
             print(data[key])
          except:
             c.send("HTTP /1.1 404 NOT FOUND\r\n\r\n".encode())
             print("404 NOT FOUND")
      elif recvmsg[0:3] == "PUT":
         key = recvmsg.split("/")[2]
         value = recvmsg.split("/")[3].split()[0]
         data[key] = value
         c.send("HTTP /1.1 201 CREATED\r\n\r\n".encode())
         print("inserted "+data[key])
      elif recvmsg[0:6] == "DELETE":
         key = recvmsg.split("/")[2].split()[0]
         try:
            value = data[key]
            # c.send("key-value pair deleted".encode())
            # print(data[key])
            del data[key]
            c.send("HTTP /1.1 200 OK\r\n\r\n".encode())
         except:
            c.send("HTTP /1.1 404 NOT FOUND\r\n\r\n".encode())
            print("404 NOT FOUND")
         # print("deleted"+data[key])
         # del data[key]




  #Write your code here
  #1. Uncomment c.send
  #2. Parse the received HTTP request
  #3. Do the necessary operation depending upon whether it is GET, PUT or DELETE
  #4. Send response
  ##################

  c.close()
  #break
