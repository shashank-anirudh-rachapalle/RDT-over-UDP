import socket

server_ip = "10.0.1.2"
dist_ip = "10.0.1.3"
port = 12346

server = socket.socket()

client = socket.socket()
client.connect((dist_ip, port))


server.bind((server_ip, port))
server.listen(5)
print("Cache server is listening...")

cache_data = {}

while True:
  c, addr = server.accept()
  print ('Got connection from', addr )
  # recvmsg = c.recv(1024).decode()
  # print('cache received '+recvmsg)
  while True:
      print("\n")
      recvmsg = c.recv(1024).decode()
      if len(recvmsg) == 0:
          print("disconnecting with client")
          break
      print('cache received '+recvmsg)
      # print(recvmsg[0])
      if recvmsg[0:3] == "end":
          c.send("your session ended".encode())
          break
      elif recvmsg[0:3] == "GET":
          key = recvmsg.split("?")[1].split("=")[1].split()[0]
          try:
             msg = "HTTP /1.1 200 OK"+"\nvalue: " + cache_data[key]+'\r\n\r\n'
             c.send(msg.encode())
             print(cache_data[key]+" sending from cache")
          except:
              print("not in cache, requesting server")
              client.send(recvmsg.encode())
              msg_from_server = client.recv(1024).decode()
              print("cache recieved "+msg_from_server)
              if msg_from_server == "HTTP /1.1 404 NOT FOUND\r\n\r\n":
                 c.send(msg_from_server.encode())
                 print("not found in server")
              else:
                 c.send(msg_from_server.encode())
                 value_from_server = msg_from_server.split()[4]
                 cache_data[key] = value_from_server
                 print("added into cache and sent to client")

      elif recvmsg[0] == "P":
         # print("Here")
         client.send(recvmsg.encode())
         key = recvmsg.split("/")[2]
         value = recvmsg.split("/")[3].split()[0]
         # print(key,value)
         msg_from_server = client.recv(1024).decode()
         print("cache recieved "+msg_from_server)
         if key in cache_data:
             cache_data[key]=value

         c.send(msg_from_server.encode())

      elif recvmsg[0:6] == "DELETE":
         key = recvmsg.split("/")[2].split()[0]
         client.send(recvmsg.encode())
         try:
            value = cache_data[key]
            # c.send("key-value pair deleted".encode())
            # print(data[key])
            del cache_data[key]
            print("deleted in cache")
         except:
            print("not in cache")
         # print("deleted"+data[key])
         # del data[key]
         print("deleting in server...")
         msg_from_server = client.recv(1024).decode()
         print("cache recieved "+msg_from_server)
         c.send(msg_from_server.encode())

  c.close()
