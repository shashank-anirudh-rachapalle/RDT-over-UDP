import socket

serverIP = "10.0.1.2"

dst_ip = "10.0.1.2"
# str(input("Enter dstIP: "))
s = socket.socket()

print(dst_ip)

port = 12346

s.connect((dst_ip, port))

#Write your code here:
#1. Add code to send HTTP GET / PUT / DELETE request. The request should also include KEY.
#2. Add the code to parse the response you get from the server.

print("\n")
while True:
    print("enter g-get request p-put request d-delete request e-end requests")
    request = raw_input("next request:\n")
    if request == "e":
        # s.send("end connection".encode())
        # print ('Client received '+s.recv(1024).decode())
        print("ending the session"+"\n\n\n")
        s.close()
        break
    elif request == "g":
        key = raw_input("key:")
        sendmsg = "GET /assignment1?"+"request="+key+" HTTP/1.1\r\n\r\n"
        s.send(sendmsg.encode())
        print("get request for "+key)
        print ('Client received '+s.recv(1024).decode()+"\n\n\n")
    elif request == "p":
        key = raw_input("key:")
        value = raw_input("value:")
        sendmsg = "PUT /assignment1/"+key+"/"+value+" HTTP/1.1\r\n\r\n"
        s.send(sendmsg.encode())
        print ('Client received '+s.recv(1024).decode())
        print("put request for"+key+"-"+value+"\n\n\n")
    elif request == "d":
        key = raw_input("key:")
        sendmsg = "DELETE /assignment1/"+key+" HTTP/1.1\r\n\r\n"
        s.send(sendmsg.encode())
        print ('Client received '+s.recv(1024).decode())
        print("delete request for"+key+"\n\n\n")
    else:
        print("invalid request\n\n\n")


# s.close()
