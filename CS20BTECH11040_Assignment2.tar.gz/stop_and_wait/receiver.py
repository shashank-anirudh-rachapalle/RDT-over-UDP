import socket
import sys
import time

recieverIP = "10.0.0.2"
recieverPort   = 20002
bufferSize  = 1024 #Message Buffer Size

# bytesToSend = str.encode(msgFromServer)

# Create a UDP socket
socket_udp = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

# Bind socket to localIP and localPort
socket_udp.bind((recieverIP, recieverPort))

print("UDP socket created successfully....." )

throughput_log = open("throughput.txt","a")
outfile = open("output_img.jpg","wb")
start=time.time()

# rdt_recv
seq_bytes=(0).to_bytes(2,'big').decode()
prev_seq_bytes=(1).to_bytes(2,'big').decode()
msg = b''
eof_bytes=(0).to_bytes(1,'big').decode()
packet_number=1

while True:
    bytesAddressPair = socket_udp.recvfrom(bufferSize)
    recv_msg = bytesAddressPair[0]
    senderAdd = bytesAddressPair[1]
    seq_res = recv_msg[0:2]
    eof = recv_msg[2]
    if eof==1:
        print('msg delivery complete, got eof indication')
        ack = seq_bytes.encode()+b"ACK"
        socket_udp.sendto(ack, senderAdd)
        break
    elif seq_res != seq_bytes.encode():
        ack = prev_seq_bytes.encode()+b"ACK"
        socket_udp.sendto(ack,senderAdd)
    else:
        print("packet number = "+str(packet_number))
        packet_number+=1
        msg+=recv_msg[3:]
        prev_seq_bytes = seq_bytes
        ack = seq_bytes.encode()+b"ACK"
        socket_udp.sendto(ack,senderAdd)
        seq_bytes = ((int.from_bytes(seq_bytes.encode(),'big')+1)%2).to_bytes(2,'big').decode()

total_time = time.time()-start
throughput_log.write("Throghput: "+str(len(msg)/(1024*total_time))+"\n")
throughput_log.close()
outfile.write(msg)
outfile.close()
# while True:
#
#     #wait to recieve message from the server
#     bytesAddressPair = socket_udp.recvfrom(bufferSize)
#     print(bytesAddressPair) #print recieved message
#
#     #split the recieved tuple into variables
#     recievedMessage = bytesAddressPair[0]
#     senderAddress = bytesAddressPair[1]
#
#     #print them just for understanding
#     msgString = "Message from Client:{}".format(recievedMessage)
#     detailString  = "Client IP Address:{}".format(senderAddress)
#     print(msgString)
#     print(detailString)
#
#     # Sending a reply to client
#     message = str.encode("This is a reply message from the server")
#     socket_udp.sendto(message, senderAddress)
