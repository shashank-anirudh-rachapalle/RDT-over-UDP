import socket
import sys

senderIP = "10.0.0.1"
senderPort   = 20001
recieverAddressPort = ("10.0.0.2", 20002)
bufferSize  = 1024 #Message Buffer Size

packet_timeout = input("set timeout(in ms): ")
packet_timeout = int(packet_timeout)

# Create a UDP socket at reciever side
socket_udp = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
socket_udp.settimeout(packet_timeout/1000)

retransmission_log = open("retransmissions.txt","a")

img_file = open("msg_img.jpg","rb")
img = img_file.read()

#rdt_send(img)
limit = bufferSize-3
len = len(img)
no_of_retransmissions = 0
seq_bytes = (0).to_bytes(2,'big').decode()
eof_bytes = (0).to_bytes(1,'big').decode()
sent_length = 0
while sent_length<len:
    msg_to_be_sent = seq_bytes.encode()+eof_bytes.encode()+img[sent_length:sent_length+limit]
    socket_udp.sendto(msg_to_be_sent,recieverAddressPort)

    while True:
        try:
            response = socket_udp.recvfrom(bufferSize)[0]
        except socket.timeout:
            print('Timeout for the packet')
            print('Retransmitting')
            socket_udp.sendto(msg_to_be_sent,recieverAddressPort)
            no_of_retransmissions+=1
        else:
            seq_response = response[0:2]
            ack = response[2:]
            if ack == b"ACK" and seq_response == seq_bytes.encode():
                sent_length+=limit
                seq_integer = int.from_bytes(seq_bytes.encode(),'big')
                seq_bytes = ((seq_integer+1)%2).to_bytes(2,'big').decode()
                break

# sending eof Message
msg_to_be_sent = seq_bytes.encode()+(1).to_bytes(1,'big')
socket_udp.sendto(msg_to_be_sent,recieverAddressPort)
retransmission_log.write(str(packet_timeout)+"    "+str(no_of_retransmissions)+"\n")


img_file.close()
retransmission_log.close()

# while True:

    # # Send to server using created UDP socket
    # msg = input("Please enter message to send: ")
    # message = str.encode(msg)
    # socket_udp.sendto(message, recieverAddressPort)
    #
    # #wait for reply message from reciever
    # msgFromServer = socket_udp.recvfrom(bufferSize)
    #
    # msgString = "Message from Server {}".format(msgFromServer[0])
    # print(msgString)
