import socket
import sys
import time

recieverIP = "10.0.0.2"
recieverPort   = 20002
bufferSize  = 1024 #Message Buffer Size

# bytesToSend = str.encode(msgFromServer)

# Create a UDP socket
socket_udp = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

# Bind socket to localIP and localPort
socket_udp.bind((recieverIP, recieverPort))

print("UDP socket created successfully....." )

throughput_log = open("throughput.txt","a")
outfile = open("output.jpg","wb")
start=time.time()

# rdt_recv
seq_bytes=(0).to_bytes(2,'big')
prev_seq_bytes=(0).to_bytes(2,'big')
msg = b''
eof_bytes=(0).to_bytes(1,'big')
packet_number=1

while True:
    recv_msg,senderAdd = socket_udp.recvfrom(bufferSize)
    seq_res = recv_msg[0:2]
    eof = recv_msg[2]
    if seq_res != seq_bytes:
        ack = prev_seq_bytes+b"ACK"
        socket_udp.sendto(ack,senderAdd)
    else:
        print("packet number = "+str(packet_number))
        packet_number+=1
        msg+=recv_msg[3:]
        prev_seq_bytes = seq_bytes
        ack = seq_bytes+b"ACK"
        socket_udp.sendto(ack,senderAdd)
        seq_bytes = (int.from_bytes(seq_bytes,'big')+1).to_bytes(2, "big")

        # print(seq_bytes)
        if eof:
            print('msg delivery complete, got eof indication')
            break
end = time.time()
total_time = end-start
throughput_log.write("Throghput: "+str(len(msg)/(total_time*1024))+"\n")
throughput_log.close()
outfile.write(msg)
outfile.close()
