--> open the directory in terminal
--> enter the command "sudo mn" to start a mininet in the directory
--> enter the command "xterm h1 h2" to start the hosts h1 and h2 in the mininet
--> enter the command "bash h2.sh" and then "python3 receiver.py" in h2 to start the receiver
--> enter the command "bash h1.sh" and then "python3 sender.py" in h1 to start the sender
--> specify the window size
--> specify the retransmission timeout in ms according to the instructions on the console.

--the sender.py program sends the msg_img.jpg image file to the receiver program
  running on host h2.
--The number of retransmissions along with the retransmission timeout is added to retransmissions.txt
--The overall throughput is added to throughput.txt
--the packet loss is fixed to 0.5%
