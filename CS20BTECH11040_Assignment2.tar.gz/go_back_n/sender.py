import socket
import sys

senderIP = "10.0.0.1"
senderPort   = 20001
recieverAddressPort = ("10.0.0.2", 20002)
bufferSize  = 1024 #Message Buffer Size
window = input("Input N value:")
window=int(window)

packet_timeout = input("set timeout(in ms): ")
packet_timeout = int(packet_timeout)
# packet_timeout=25

# Create a UDP socket at reciever side
socket_udp = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
socket_udp.settimeout(packet_timeout/1000)

retransmission_log = open("retransmissions.txt","a")

img_file = open("msg_img.jpg","rb")
img = img_file.read()

#rdt_send(img)
limit = bufferSize-3
img_len = len(img)
no_of_retransmissions = 0
eof_bytes = (0).to_bytes(1,'big')

packets = []

# Splitting into packets
sent_length = 0
seq_number = 0
base = 0

while img_len >= sent_length:
    last = sent_length + limit
    if last > img_len:
        last = img_len
        eof_bytes=int(1).to_bytes(1,'big')
    packet = (seq_number).to_bytes(2, "big") + eof_bytes + img[sent_length:last]
    # print(len(packet))
    packets.append(packet)
    seq_number =seq_number+1
    sent_length = sent_length + limit


# Fill the Buffer
buffer = []
for i in range(0, min(len(packets),window)):
    buffer.append(packets[i])
    socket_udp.sendto(packets[i], recieverAddressPort)
# buffer.append(packets[:window])
next_seq = window
print(len(packets))
# Start sending packets
# for packet in buffer:
#     socket_udp.sendto(packet, recieverAddressPort)

while len(buffer) > 0:
    # print(len(buffer))
    # In case of Timeout
    try:
        msg_recv = socket_udp.recvfrom(bufferSize)
    except socket.timeout:
        print("Timeout, Retransmitting...")
        # Resend all the packets in the buffer
        for packet in buffer:
            socket_udp.sendto(packet, recieverAddressPort)
    else:
        response = msg_recv[0]
        seq_res = response[0:2]
        seq_res = int.from_bytes(seq_res, "big")
        index = seq_res-base+1
        base = seq_res + 1

        for _ in range(0, index):
            buffer.pop(0)
            if len(packets)>next_seq:
                buffer.append(packets[next_seq])
                socket_udp.sendto(packets[next_seq], recieverAddressPort)
                next_seq = next_seq + 1



# sending eof Message
msg_to_be_sent = (0).to_bytes(2, "big")+(1).to_bytes(1,'big')
socket_udp.sendto(msg_to_be_sent,recieverAddressPort)
print("Sent eof thing")


img_file.close()
retransmission_log.close()

# while True:

    # # Send to server using created UDP socket
    # msg = input("Please enter message to send: ")
    # message = str.encode(msg)
    # socket_udp.sendto(message, recieverAddressPort)
    #
    # #wait for reply message from reciever
    # msgFromServer = socket_udp.recvfrom(bufferSize)
    #
    # msgString = "Message from Server {}".format(msgFromServer[0])
    # print(msgString)
